﻿var ImageUrl = "";
var Pid = "";
var GroupId = $("#groupid").val();
var isJoin = false;
var CheckUserIsJoinGroup = function() {

    $.ajax({
        url: "/profile/AJaxCheckUserIsJoinGroup",
        type: 'post',
        dataType: 'text',
        timeout: 10000,
        data: { GroupId: GroupId },
        async: false,
        success: function(resultData) {
            if (resultData == "joined") {
                isJoin = true;
                $.jBox.tip('您已经加入', 'success');

            } else {
                isJoin = false;
                $.jBox.confirm("确定加入此小组确定吗？", "提示", submit);
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          
        }
    });
    return isJoin;
};

var submitJoin = function (v, h, f) {
    if (v == 'ok') {
        $.ajax({
            url: "/profile/AjaxJoinGroup",
            type: 'post', dataType: 'text', timeout: 10000,
            async: false,
            data: { GroupId: GroupId },
            success: function (resultData) {
                if (resultData == "joined") {
                    isJoin = true;
                    $.jBox.tip('您已经加入', 'success');
                }
                else if (resultData == "Yes") {
                    isJoin = true;
                    $.jBox.tip('您已经成功加入', 'success');
                }
                else { isJoin = false; $.jBox.tip('出现异常', 'error'); }

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                ShowFailTip("操作失败：" + errorThrown);
            }
        });
    }
    return isJoin;
};


$(function() {
    Upload($("#UploadPhoto"));
    $("#addProduct").click(addProduct);
    $("#LoadUrlShow").click(function() { $("#LoadProductWindow").fadeIn(300); });
    $("#LoadUrlClose").click(function() { $("#LoadProductWindow").fadeOut(300); });
    $("#biaoqingclose").click(function() { $("#tbiaoqing").hide(); });
    $(".biaoqingshow").click(function(e) {
        e.preventDefault();
        $("#tbiaoqing").slideToggle(0);
    });
    $("#CancelImage").click(function(e) {
        e.preventDefault();
        $("#yulanImage").fadeOut(300);
    });
    $("#SubmitTopic").click(function() {
        var Title = $("#titleTopic").val();
        var Des = $("#contentTopic").val();
        if (Title == "" || Des == "") {
            $.jBox.tip('请填写完整', 'error');
            return;
        }
        var GroupId = $.getUrlParam("GroupId");
        $.ajax({
            url: "/profile/AJaxCreateTopic",
            type: 'post',
            dataType: 'text',
            timeout: 10000,
            data: { ImageUrl: ImageUrl, Title: Title, Des: Des, Pid: Pid, GroupId: GroupId },
            success: function(resultData) {
                if (resultData == "No") {

                } else {
                    var mediaIds = "";
                    if ($(".isSendAll").attr('checked') != undefined) {
                        mediaIds = "-1";
                    } else {
                        var i = 0;
                        $(".bind>span").each(function() {
                            if ($(this).attr("s_type") == "1" && $(this).attr("value") != "") {
                                if (i == 0) {
                                    mediaIds = $(this).attr("value");
                                } else {
                                    mediaIds = mediaIds + "," + $(this).attr("value");
                                }
                                i++;
                            }
                        });
                    }

                    //同步到微博
                    var Option = {
                        ShareDes: Title,
                        ImageUrl: ImageUrl,
                        TopicID: resultData,
                        mediaIds: mediaIds
                    };
                    InfoSync.InfoSending(Option);
                    window.location = "/Group/GroupInfo?GroupId=" + GroupId + "";
                }

            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    });
});
function Upload(control) {
    var button = control, interval;
    var fileType = "all", fileNum = "more";
    new AjaxUpload(button, {
        action: '/Ajax_Handle/SNSUploadPhoto.ashx',
        data: {
            'Type': 'Post'
        },
        name: 'myfile',
        onSubmit: function (file, ext) {
            $.jBox.tip("正在上传...", 'loading');
            if (fileType == "pic") {
                if (ext && /^(jpg|png|jpeg|gif)$/.test(ext)) {
                    this.setData({
                        'info': '文件类型为图片'
                    });
                } else {
                    $.jBox.tip('请上传图片类型');
                    return false;
                }
            }
            if (fileNum == 'one')
                this.disable();
        },
        onComplete: function (file, response) {
            if (response == "-1") {
                $.jBox.tip('上传图片不能大于500k');
                return;
            }
            $.jBox.tip('上传成功', 'success');
            ImageUrl = response;
            $("#yulantu").attr("src", ImageUrl.split("|")[2]);
            $("#yulanImage").fadeIn(300);

        }
    });
}
function addProduct() {
    var LinkUrl = $("#ProductLink").val() + "&";
    ImageUrl = "";
    var urlreg = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w- .\/?%&=]*)?/;
    if (LinkUrl && LinkUrl.length > 0 &&
                        !urlreg.test(LinkUrl)) {
        $.jBox.tip('请输入正确的链接', 'success');
        return false;
    }
    $.jBox.tip("努力给您获取中...", 'loading');
    $.ajax({
        url: "/profile/AjaxGetProductInfo",
        type: 'post', dataType: 'text', timeout: 10000,
        data: { ProductLink: LinkUrl },
        success: function (resultData) {
            if (resultData == "No") {
                $.jBox.tip('亲，获取失败，请您换个商品试一下吧', 'error');
            }
            else {
                var Datas = resultData.split("|");
                Pid = Datas[0];
                ImageUrl = Datas[1];
                $("#yulantu").attr("src", ImageUrl);
                $("#yulanImage").fadeIn(300);
                $.jBox.tip('获取成功', 'success');
                $("#LoadProductWindow").fadeOut(300)
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $.jBox.tip('出现异常', 'error');
        }
    });
}

function insertsmilie(smilieface) {
    $("[id$='contentTopic']").val($("[id$='contentTopic']").val() + smilieface);
    $("#tbiaoqing").hide();
}
