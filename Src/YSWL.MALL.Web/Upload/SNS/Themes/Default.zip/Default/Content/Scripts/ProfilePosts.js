﻿$(function () {
    if ($.getUrlParam("type") == "all") {
        $('#AllPostBtn').removeClass('tmenu_b').addClass('tmenu_a');
        $('#FriendPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#MyPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#ReferBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#EachOtherPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
    }
    if ($.getUrlParam("type") == "user") {
        $('#AllPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#MyPostBtn').removeClass('tmenu_b').addClass('tmenu_a');
        $('#FriendPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#ReferBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#EachOtherPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
    }
    if ($.getUrlParam("type") == "referme") {
        $('#AllPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#referMyBtn').removeClass('tmenu_b').addClass('tmenu_a');
        $('#FriendPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#MyPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#EachOtherPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        //  $("#referDiv").show();
    }
    if ($.getUrlParam("type") == "ReferMyComment") {
        $('#AllPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#referMyBtn').removeClass('tmenu_b').addClass('tmenu_a');
        $('#FriendPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#MyPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#EachOtherPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
    }
    if ($.getUrlParam("type") == "eachother") {
        $('#AllPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#referMyBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#FriendPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#MyPostBtn').removeClass('tmenu_a').addClass('tmenu_b');
        $('#EachOtherPostBtn').removeClass('tmenu_b').addClass('tmenu_a');
    }
    if (parseInt($("#pointer").val()) > 0) {
        $.MessageShow("登录成功！积分，<span style='color:yellow;font-weight: bolder;'>+" + $("#pointer").val() + "</span>");
    }
});
///发动态，内容框变颜色
$(function () {
    $("#contentWeibo").focus(function () {
        $(this).parent().css("border", "#FCD559 1px solid");
    }).blur(function () { $(this).parent().css("border", "#D2D2D2 1px solid"); });
});
var ImageUrl, Type, Pid, AblumId, TargetID, VideoUrl, PostExUrl,VideoRawUrl,AudioUrl, MusicTipisShow="",ProductName;
// VideoUrl = "http://v.youku.com/v_show/id_XNDcyODQxMTk2.html";
function Upload(control, type) {
    Type = type;
    var button = control, interval;
    var fileType = "all", fileNum = "more";
    new AjaxUpload(button, {
        action: '/Ajax_Handle/SNSUploadPhoto.ashx',
        data: {
            'Type': 'Post'
        },
        name: 'myfile',
        onSubmit: function (file, ext) {
            $("#LoadAudioWindow").hide(); $("#yulantu").hide(); $("#yulanvideo").hide();
            $.jBox.tip("正在上传...", 'loading');
            if (fileType == "pic") {
                if (ext && /^(jpg|png|jpeg|gif)$/.test(ext)) {
                    this.setData({
                        'info': '文件类型为图片'
                    });
                } else {
                    $.jBox.tip('请上传图片类型');
                    return false;
                }
            }
            if (fileNum == 'one')
                this.disable();
        },
        onComplete: function (file, response) {
            if (response == "-1") {
                $.jBox.tip('上传图片不能大于500k');
                return;
            }
            $.jBox.tip('上传成功', 'success');
            ImageUrl = response;
            VideoUrl = "";
            AudioUrl = "";
            PostExUrl = "";
            if (type == "Photo") {
                $("#imagetype").show();
                $("#UploadPhotoWindow").hide();
                if ($("#con_one_2").children().length < 2) {
                    if ($("#con_one_3").children("#PhotoResultWindow")) {
                        $("#con_one_3").children("#PhotoResultWindow").remove();
                    }
                    LoadAblumFun();
                    $("#con_one_2").append($("#PhotoResultTemplate").html().format(response.split("|")[1], "Photo"));
                }
                else {
                    $("#picinfo").attr("src", response.split("|")[1]);
                    $("#PhotoResultWindow").show();
                }
            }
            else if (type == "Image") {
                $("#yulantuimage").attr("src", response.split("|")[0]);
                $("#yulantu").fadeIn(300);
                $("#contentWeibo").val($("#contentWeibo").val() + "分享图片");
                resizeImg('#yulantu', 211, 1280);
            }
        }
    });
}
function DelYulanTu() {
    $.ajax({
        url: "/profile/AjaxDelYulanTu",
        type: 'post', dataType: 'text', timeout: 10000,
        data: { ImageUrl: ImageUrl },
        success: function (resultData) {
            if (resultData == "No") {
                $.jBox.tip("操作失败...", 'error');
            }
            else {
                ImageUrl = "";
                $("#yulantu").fadeOut(300);
                $("#yulantuimage").attr("src", "");
                $("#imagename").text("");
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            ShowFailTip("操作失败：" + errorThrown);
        }
    });
}
function addProduct() {
    var LinkUrl = $("#ProductLink").val() + "&";
    ImageUrl = "";
    var urlreg = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w- .\/?%&=]*)?/;
    if (LinkUrl && LinkUrl.length > 0 &&
                        !urlreg.test(LinkUrl)) {
        $.jBox.tip('请输入正确的链接', 'success');
        return false;
    }
    $.jBox.tip("努力给您获取中...", 'loading');
    $.ajax({
        url: "/profile/AjaxGetProductInfo",
        type: 'post', dataType: 'text', timeout: 10000,
        data: { ProductLink: LinkUrl },
        success: function (resultData) {
            if (resultData == "No") {
                $.jBox.tip('亲，获取失败，请您换个商品试一下吧', 'error');
            }
            else {
                var Datas = resultData.split("|");
                $("#UploadProductWindow").hide();
                Pid = Datas[0];
                ImageUrl = Datas[1];
                if ($("#con_one_3").children().length < 2) {
                    if ($("#con_one_2").children("#PhotoResultWindow")) {
                        $("#con_one_2").children("#PhotoResultWindow").remove();
                    }
                    LoadAblumFun();
                    $("#con_one_3").append($("#PhotoResultTemplate").html().format(Datas[1], "Product"));

                }
                else {
                    $("#picinfo").attr("src", Datas[1]);
                    $("#PhotoResultWindow").show();
                }
                $.jBox.tip('获取成功', 'success');
                VideoUrl = "";
                PostExUrl = "";
                AudioUrl = "";
                ProductName = Datas[2];
                $("#imagetype").hide();

            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            ShowFailTip("操作失败：" + errorThrown);
        }
    });
}
function addPost(type) {
    var ShareDes = $("#contentWeibo").val();
    var ImageType = $('input[name="selecttype"]:checked').val();
    if (type == "Photo") {
        ShareDes = $("#contentPhoto").val();
    }
    if (type == "Product") {
        ShareDes = $("#contentProduct").val();
    }
    if (type == "Weibo" && $("#contentWeibo").val() == "") {

        $.jBox.tip('请输入内容', 'success');
        return;
    }
    if (type == "Weibo" &&$.cookie("contentWeibo")==$("#contentWeibo").val()&&ImageUrl==""&&VideoUrl==""&&AudioUrl=="") {
        $.jBox.tip('同样的内容不能连着发两次', 'error');
        return;
    }
    if (type!= "Weibo"&&($("#myAlbums").val() == null || $("#myAlbums").val()=='undefined')) {
        $.jBox.tip('请先选择或新建专辑', 'error');
        return;
    }
    $.ajax({
        url: "/profile/AjaxPostAdd",
        type: 'post', dataType: 'text', timeout: 10000,
        async: false,
        data: { Type: type, ImageUrl: ImageUrl, ShareDes: ShareDes, AblumId: $("#myAlbums").val(), Pid: Pid, ImageType: ImageType, VideoUrl: VideoUrl, PostExUrl: PostExUrl, AudioUrl: AudioUrl, ProductName: ProductName },
        success: function (resultData) {
            if (resultData == "No") {
                ShowFailTip("操作失败，请您重试！");
            }
            else if (resultData == "AA")
            { $.jBox.tip('管理员不能操作', 'error'); }
            else if (resultData == "ProductRepeat")
            { $.jBox.tip('同样的商品您已经发布了一次', 'error'); }
            else {
                var data = $(resultData);
                TargetID = data.find(".favourite").attr("targetid");
                var PostID = data.find(".CreateReport").attr("targetid");
                data.hide();
                $("#PostAllContent").prepend(data);
                data.slideDown();
                if (type == "Photo") {
                    $("#UploadPhotoWindow").show();
                    $("#contentPhoto").val("");
                    $("#PhotoResultWindow").hide();
                }
                if (type == "Product") {
                    Pid = 0;
                    $("#UploadProductWindow").show();
                    $("#ProductLink").val("");
                    $("#contentProduct").val("");
                    $("#PhotoResultWindow").hide();
                }
                if (type == "Weibo") {
                    $.cookie("contentWeibo", $("#contentWeibo").val());
                    $("#contentWeibo").val("");
                    $("#yulantu").fadeOut(300);
                    $("#yulanvideo").fadeOut(300);
                }
                var mediaIds = "";
                AddPoint(type);
                if (type == "Weibo") {
                    var i = 0;
                    if ($("#postWeibo").parents(".lyz_tab_right_b").find(".isSendAll").attr('checked') != undefined) {
                        mediaIds = "-1";
                    } else {
                        $(".lyz_tab_right_b>.bind>span").each(function () {
                            if ($(this).attr("s_type") == "1" && $(this).attr("value") != "") {
                                if (i == 0) {
                                    mediaIds = $(this).attr("value");
                                } else {
                                    mediaIds = mediaIds + "," + $(this).attr("value");
                                }
                                i++;
                            }
                        });
                    }
                } else if (type == "Photo") {
                    {
                        var i = 0;
                        if ($("#postPhoto").parents(".fabiao_cs").find(".isSendAll").attr('checked') != undefined) {
                            mediaIds = "-1";
                        } else {
                            $("#postPhoto").parents(".fabiao_cs").find(".bind>span").each(function () {
                                if ($(this).attr("s_type") == "1" && $(this).attr("value") != "") {
                                    if (i == 0) {
                                        mediaIds = $(this).attr("value");
                                    } else {
                                        mediaIds = mediaIds + "," + $(this).attr("value");
                                    }
                                    i++;
                                }
                            });
                        }

                    }
                } else if (type == "Product") {
                    {
                        var i = 0;
                        if ($("#postProduct").parents(".fabiao_cs").find(".isSendAll").attr('checked') != undefined) {
                            mediaIds = "-1";
                        } else {
                            $("#postProduct").parents(".fabiao_cs").find(".bind>span").each(function () {
                                if ($(this).attr("s_type") == "1" && $(this).attr("value") != "") {
                                    if (i == 0) {
                                        mediaIds = $(this).attr("value");
                                    } else {
                                        mediaIds = mediaIds + "," + $(this).attr("value");
                                    }
                                    i++;
                                }
                            });
                        }

                    }
                }


                //同步到微博
                var Option = {
                    Type: type,
                    ShareDes: ShareDes,
                    ImageUrl: ImageUrl,
                    TargetID: TargetID,
                    PostID: PostID,
                    VideoRawUrl: VideoRawUrl,
                    mediaIds: mediaIds
                };
                InfoSync.InfoSending(Option);
                //以上是同步到微博
                ImageUrl = "";
                VideoUrl = "";
                AudioUrl = "";
                TargetID = "";
                PostID = "";
                VideoRawUrl = "";
                mediaIds = "";
                data.slideDown();
                $("#imagetype").hide();


            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            ShowFailTip("操作失败：" + errorThrown);
        }
    });
}

function AddPoint(type) {
    $.ajax({
        url: "/profile/AjaxAddPoint",
        type: 'post', dataType: 'text', timeout: 10000,
        data: { Type: type },
        success: function (resultData) {
            if (parseInt(resultData) > 0) {
                $.MessageShow("恭喜！积分，<span style='color:yellow;font-weight: bolder;'>+" + resultData + "</span>");
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            ShowFailTip("操作失败：" + errorThrown);
        }
    });
}
var submitAlbum = function (v, h, f) {
    var html;
    if (f.AlbumName == '') {
        $.jBox.tip('请填写专辑的名称', 'success');
        return;
    }
    if (!f.albumtype) {
        $.jBox.tip('请选择类型', 'success');
        return;
    }
    $.ajax({
        url: "/profile/AjaxAddAlbum",
        type: 'post', dataType: 'text', timeout: 10000,
        data: { AlbumName: f.AlbumName, Type: f.albumtype },
        success: function (resultData) {
            if (resultData == "No") {
            }
            else {
                html += "<option selected='selected' value=" + resultData + ">" + f.AlbumName + "</option>";
                $("#myAlbums").append(html);
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            ShowFailTip("操作失败：" + errorThrown);
        }
    });
    $.jBox.tip('创建成功', 'success');
    return true;
};
$("#createAlblums").live("click", function () {
    var html = "", ResultHtml = "";
    $('.cre_a_2b input:first').attr('checked', 'true');
    html = $("#CreateAlbumsTemplate").html();
    $.jBox(html, { title: "新建专辑", buttons: { '创建': 1 }, submit: submitAlbum, width: 400, top: 300 });
});
function LoadAblumFun() {
    $.ajax({
        url: "/profile/AjaxGetMyMyAblum",
        type: 'post', dataType: 'text', timeout: 10000,
        success: function (resultData) {
            if (resultData == "No") {
                ShowFailTip("操作失败，请您重试！");
            }
            else {
                var Datas = $.parseJSON(resultData);
                var html;
                for (var i = 0; i < Datas.length; i++) {
                    html += "<option value=" + Datas[i].AlbumID + ">" + Datas[i].AlbumName + "</option>";
                }
                $("#myAlbums").html(html);
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            ShowFailTip("操作失败：" + errorThrown);
        }
    });
}
function TopicFun() {
    $("#topic").click(function (e) {
        e.preventDefault();
        $("#contentWeibo").val($("#contentWeibo").val() + "#此处插入话题#");
    });
}

$(function () {
    $("#delyulavideo").click(function (e) {
        e.preventDefault();
        $("#yulanvideo").hide();
        VideoRawUrl = "";
        VideoUrl = "";
        PostExUrl = "";
        if (e && e.stopPropagation)
        //因此它支持W3C的stopPropagation()方法 
            e.stopPropagation();
        else
        //否则，我们需要使用IE的方式来取消事件冒泡 
            window.event.cancelBubble = true; 
        $("#contentWeibo").val("");

    });
    $("#addVideo").click(function (e) {

        var videourlVal = $.trim($('#txtVideoUrl').val());
        if (videourlVal == "") {
            $("#txtVideoUrl").empty();
            $.jBox.tip('视频地址不能为空', 'error');
            return false;
        }
        //$.jBox.tip("努力给您获取中...", 'loading');
        var errnum = 0;
        $.ajax({
            url: "/Profile/CheckVideoUrl",
            type: 'post',
            dataType: 'json',
            timeout: 10000,
            async: false,
            data: {
                Action: "post",
                VideoUrl: videourlVal
            },
            success: function (JsonData) {

                switch (JsonData.STATUS) {
                    case "NotNull":
                        $("#txtVideoUrl").empty();
                        $.jBox.tip('视频地址不能为空', 'error');
                        break;
                    case "Error":
                        $("#txtVideoUrl").empty();
                        $.jBox.tip('视频地址错误', 'error');
                        break;
                    case "Succ":

                        VideoUrl = JsonData.VideoUrl;
                        PostExUrl = JsonData.ImageUrl;
                        $("#contentWeibo").val("分享视频 ");
                        $("#LoadVideoWindow").hide();
                        VideoRawUrl = $("#txtVideoUrl").val();
                        $("#txtVideoUrl").val("");
                        $("#yulanvideo").show();
                        $("#yulantuvideo").attr("src", PostExUrl);
                        $("#loadingvideo").hide();
                        $("#yulantuvideo").show();
                        ImageUrl = "";
                        Pid = "";

                        break;
                    default:
                        errnum++;
                        $.jBox.tip('服务器没有返回数据，可能服务器忙，请稍候再试', 'error');
                        break;
                }

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                errnum++;
                $.jBox.tip('服务器没有返回数据，可能服务器忙，请稍候再试', 'error');
            }
        });
        if (e && e.stopPropagation)
        //因此它支持W3C的stopPropagation()方法 
            e.stopPropagation();
        else
        //否则，我们需要使用IE的方式来取消事件冒泡 
            window.event.cancelBubble = true; 
        return errnum == 0 ? true : false;
    });
});
// 验证视频地址
function CheckVideo(e) {

}
$(function () {
    Upload($("#UploadImage"), "Image");
    Upload($("#UploadPhoto"), "Photo");
    $("#addProduct").click(addProduct);
    $("#delyulatu").click(DelYulanTu);
    $("#postWeibo").click(function () { addPost("Weibo"); });
    $("#postProduct").live("click", function (e) {
        e.preventDefault(); addPost("Product");
    });
    $("#postPhoto").live("click", function (e) { e.preventDefault(); addPost("Photo"); });
    TopicFun();
    $("#biaoqingclose").click(function () { $("#tbiaoqing").hide(); });
    $("#biaoqingshow").click(function (e) { e.preventDefault(); $("#tbiaoqing").slideToggle(0);
    });
    $("#UploadVideo").click(function (e) { e.preventDefault(); $("#LoadVideoWindow").show(); $("#LoadAudioWindow").hide(); $("#yulantu").hide(); $("#yulanvideo").hide(); });
    $("#UploadAudio").click(function (e) { e.preventDefault(); $("#LoadAudioWindow").show(); $("#LoadVideoWindow").hide(); $("#yulantu").hide(); $("#yulanvideo").hide(); });
    $("#LoadUrlClose").click(function (e) {
        e.preventDefault();
        $("#LoadVideoWindow").hide();
        if (e && e.stopPropagation)
        //因此它支持W3C的stopPropagation()方法 
            e.stopPropagation();
        else
        //否则，我们需要使用IE的方式来取消事件冒泡 
            window.event.cancelBubble = true; 
     
     $("#txtVideoUrl").val(""); });
 $("#LoadAudioClose").click(function (e) {
     e.preventDefault(); $("#LoadAudioWindow").hide();

     if (e && e.stopPropagation)
     //因此它支持W3C的stopPropagation()方法 
         e.stopPropagation();
     else
     //否则，我们需要使用IE的方式来取消事件冒泡 
         window.event.cancelBubble = true; 
    
    $("#search_input").val("");
    });
    $(".music_list li").live('click', function () {
        // <h3>曲名：' + $(this).attr("name") + '</h3>
        var PL = '<embed src="http://www.xiami.com/widget/470304_' + $(this).attr("id") + '/singlePlayer.swf" type="application/x-shockwave-flash" width="257" height="33" wmode="transparent"></embed>';
        AudioUrl = PL;
        ImageUrl = "";
        VideoUrl = "";
        VideoRawUrl = "";
        var posttext = "分享音乐：" + $(this).attr("name") + "";
        $("#contentWeibo").val(posttext);
        $("#LoadAudioClose").click();
    });
    $("#SearchAudio").click(function () {
        searchMusicList(1);
        MusicTipisShow = true;
    });

});

function insertsmilie(smilieface) {
    $("[id$='contentWeibo']").val($("[id$='contentWeibo']").val() + smilieface);
    $("#tbiaoqing").hide();
}




function setTab(name, cursel, n) {
    for (i = 1; i <= n; i++) {
        var menu = document.getElementById(name + i);
        var con = document.getElementById("con_" + name + "_" + i);
        menu.className = i == cursel ? "hover" : "";
        //con.style.display = i == cursel ? "block" : "none";
        i == cursel ? $(con).show() : $(con).hide();
        $(con).parent().hide().fadeIn(10);
    }
}
