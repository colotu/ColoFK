﻿//检查是否登录
var CheckUserState = function() {
    var islogin;
    $.ajax({
        url: "/User/CheckUserState",
        type: 'post',
        dataType: 'text',
        timeout: 10000,
        async: false,
        success: function(resultData) {
            if (resultData != "Yes") {
                var html = "<div style='margin-left:90px;margin-top:20px;font-size: 16px;font-weight: bold;'>账号：<input type='text' style='height: 30px;width: 200px;' id='loginname' name='name' /><span style='display:none;color:red;font-size: 16px;' name='tipname' id='tipname'>账号！！</span></div>"
                html += "<div style='margin-left:90px;margin-top:20px;font-size: 16px;font-weight: bold;'>密码：<input type='password' style='height: 30px;width: 200px;' id='loginpwd' name='pwd' /><span style='display:none;color:red;font-size: 16px;' name='tippwd' name='tippwd'>密码！！</span></div>";
                html += "<div class='login'><ul><li><a href='#' id='ajaxlogin'> <img src='/Areas/SNS/Themes/Default/Content/images/login.jpg'></a></li></ul>";
                html += "<ul><li><a href='/Account/Register'><img src='/Areas/SNS/Themes/Default/Content/images/reg.jpg'></a></li></ul>";
                html += "<ul><li><a href='http://open.denglu.cc/transfer//sina?appid=" + resultData + "'><img src='/Areas/SNS/Themes/Default/Content/images/sin.jpg'></a></li><li><a href='http://open.denglu.cc/transfer//sina?appid=" + resultData + "'>新浪微博</a></li></ul>";
                html += "<ul><li><a href='http://open.denglu.cc/transfer/tencent?appid=" + resultData + "'><img src='/Areas/SNS/Themes/Default/Content/images/tengxun.jpg'></a></li><li><a href='http://open.denglu.cc/transfer/tencent?appid=" + resultData + "'>腾讯微博</a></li></ul>";
                html += "<ul><li><a href='http://open.denglu.cc/transfer/qzone?appid=" + resultData + "'> <img src='/Areas/SNS/Themes/Default/Content/images/qq.jpg'></a></li> <li><a href='http://open.denglu.cc/transfer/qzone?appid=" + resultData + "'>QQ登录</a></li></ul></div>";
                $.jBox(html, { title: "登录", submit: submitLogin, width: 550, top: 300, height: 250, buttons: { '登录': true } });
                $(".jbox-button").hide();
                islogin = false;
                return false;
            } else {
                islogin = true;
                return true;

            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          
        }
    });

    return islogin;
};
var CheckUserLogin = function() {
    var islogin;
    $.ajax({
        url: "/User/CheckUserState",
        type: 'post',
        dataType: 'text',
        timeout: 10000,
        async: false,
        success: function(resultData) {
            if (resultData != "Yes") {
                islogin = false;
                return false;
            } else {
                islogin = true;
                return true;

            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          
        }
    });
    return islogin;
};


$("#ajaxlogin").live("click", function () {$(".jbox-button").click();});
var submitLogin = function (v, h, f) {
    if (f.name == '') {
        $("#tipname").show();
        $("#tippwd").hide();
        return false;
    }
    if (f.pwd == '') {
        $("#tippwd").show();
        $("#tipname").hide();
        return false;
    }
    $.ajax({
        type: "POST",
        dataType: "text",
        url: "/Account/AjaxLogin",
        async: false,
        data: { UserName: $("#loginname").val(), UserPwd: $("#loginpwd").val() },
        success: function (data) {
            if (parseInt(data.split("|")[0]) > 0) {
                AjaxLoginGetUserInfo(data.split("|")[1]);
                return true;
            }
            else {
                $.jBox.tip('用户名或者密码不正确，请重试', 'success');

            }
        }
    });
    return true;
};
var AjaxLoginGetUserInfo = function(pointer) {
    $.ajax({
        type: "get",
        dataType: "text",
        url: "/Partial/Header",
        data: { pointer: pointer},
        success: function(data) {
            $(".headers").html(data);
        }
    });
};
$(".jbox-button").hide();
//加入专辑的弹出框
var submitAddAlbum = function (v, h, f) {
    var html;
    if (f.albumid == undefined || f.albumid <= 0) {
        $.jBox.tip('请先选择专辑！', 'fail');
    }
    else {
        $.ajax({
            url: "/Profile/AjaxAddToAlbum",
            type: 'post', dataType: 'text', timeout: 10000,
            data: { TargetId: f.targetid, Type: f.imagetype, Des: f.AddAlbumscontent, AlbumId: f.albumid },
            success: function (resultData) {
                if (resultData == "Repeat") {
                    $.jBox.tip('不能重复加入哦', 'success');
                }
                else if (resultData == "No") {
                    $.jBox.tip('加入失败，请重试', 'success');
                }
                else {
                    $.jBox.tip('成功加入', 'success');
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $.jBox.tip('加入失败，请重试', 'success');
            }
        });
        return true;
    }
};

var AJaxGetUserId = function() {
    var userid = 0;
    $.ajax({
        url: "/Profile/AjaxGetUserId",
        type: 'post',
        dataType: 'text',
        timeout: 10000,
        success: function(resultData) {
            alert(resultData);
            userid = resultData;
            return resultData;
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            return 0;
        }
    });
    return userid;

};
//添加喜欢所触发的事件
$(".favourite").live("click", function (e) {
    e.preventDefault();
    if (CheckUserState()) {
        var Type = $(this).attr("imagetype");
        var TargetID = $(this).attr("targetid");
        var NowID = $(this);
        var Number = NowID.parent().next().children("a");
        var TopicId = NowID.attr("topicid");
        var ReplyId = NowID.attr("replyid");
        $.ajax({
            type: "POST",
            dataType: "text",
            url: "/Profile/AjaxAddFavourite",
            data: { Type: Type, TargetId: TargetID, TopicId: TopicId, ReplyId: ReplyId },
            success: function (data) {
                if (data == "No") {
                    $.jBox.tip('操作出错', 'success');
                }
                else if (data == "Repeat")
                    $.jBox.tip('您已经喜欢过了', 'success');
                else {
                    Number.text(parseInt(Number.text()) + 1);

                }
            }
        });
    }
})
//加入专辑需要的事件
$(".addalbum").live("click", function (e) {
    e.preventDefault();
    if (CheckUserState()) {
        var url = $(this).attr("imageurl");
        var imagetype = $(this).attr("imagetype");
        var targetid = $(this).attr("targetid");
        $.ajax({
            type: "POST",
            dataType: "text",
            url: "/Album/GetUserAlbums",
            success: function (data) {
                var Datas = $.parseJSON(data);
                var ResultHtml = "<select style='width:200px' id='albumid' name='albumid'>"
                if (data != "No") {
                    for (var i = 0; i < Datas.length; i++) {
                        ResultHtml += " <option value =" + Datas[i].AlbumID + ">" + Datas[i].AlbumName + "</option>";
                    }
                    ResultHtml += "</select> <a  href='/Album/Create' target='_blank'>创建</a>"
                    ResultHtml += "<input type='hidden' name='imagetype' value='" + imagetype + "' />"
                    ResultHtml += "<input type='hidden' name='targetid' value='" + targetid + "' />"
                    $("#albumsinfo").html(ResultHtml);
                    $("#addToablum").find("#addtoimage").attr("src", url);
                    var html = $("#addToablum").html();
                    $.jBox(html, { title: "加入专辑", buttons: { '加入': 1 }, submit: submitAddAlbum, width: 550, top: 300 });
                }
            }
        });

    }
});