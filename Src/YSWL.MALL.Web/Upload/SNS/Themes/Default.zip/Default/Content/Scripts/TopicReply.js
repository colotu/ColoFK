﻿$(function () {
    $('#slides').slides({
        preload: true,
        preloadImage: 'images/download.gif',
        play: 5000,
        pause: 2500,
        hoverPause: true,
        animationStart: function (current) {
            $('.caption').animate({
                bottom: -35
            }, 100);
            if (window.console && console.log) {
                // example return of current slide number
                console.log('animationStart on slide: ', current);
            }
            ;
        },
        animationComplete: function (current) {
            $('.caption').animate({
                bottom: 0
            }, 200);
            if (window.console && console.log) {
                // example return of current slide number
                console.log('animationComplete on slide: ', current);
            }
            ;
        },
        slidesLoaded: function () {
            $('.caption').animate({
                bottom: 0
            }, 200);
        }
    });
});
function insertsmilieToCom(sender, smilieface) {
    $(sender).parents(".pinglunkuang").find("input").val($(sender).parents(".pinglunkuang").find("input").val() + smilieface);
    // $("[id$='contentWeibo']")
    $(".cbiaoqing").hide();
}
var ImageUrl = "";
var Pid = "";
$(function () {
    $(".AddTopicToFav").click(function () {
        var TopicId = $(this).attr("topicid");
        if (CheckUserState()) {
            $.ajax({
                url: "/profile/AjaxAddTopicToFav",
                type: 'post',
                dataType: 'text',
                timeout: 10000,
                data: { TopicId: TopicId },
                success: function (resultData) {
                    if (resultData == "Repeate") {
                        $.jBox.tip(' 您已收藏', 'success');
                    } else if (resultData == "Yes") {
                        $.jBox.tip('收藏成功', 'success');
                    } else {
                        $.jBox.tip('出现异常', 'error');
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    ShowFailTip("操作失败：" + errorThrown);
                }
            });
        }
    });
    resizeImg('.pic_load', 460, 800);
    $(".cbiaoqingshow").live("click", function (e) {
        e.preventDefault();
        $(this).parent().find(".cbiaoqing").slideToggle(0);
    });
    $(".biaoqing_b1_y").live("click", function () { $(this).parent().parent().parent().hide(); });
    $(".replyTopic").live("click", function () {
        if ($(this).parents(".answer_a_wn").find(".pinglunkuang").length == 0) {
            $(this).parents(".answer_a_wn").append($("#inputReplyTemplete").html());
            $(this).parents(".answer_a_wn").find(".btnReply").attr("replyid", $(this).attr("replyid"));
            $(this).parents(".answer_a_wn").find(".answer_a_wn_c").show(0);
        } else {
            $(this).parents(".answer_a_wn").find(".answer_a_wn_c").slideToggle(0);
        }
    });

    $(".btnReply").live("click", function () {
        var ReplyId = $(this).attr("replyid");
        var Des = $(this).parents(".answer_a_wn_c").find("input").val();
        var ObjectThis = $(this);
        if (Des == "") {
            $.jBox.tip('请填写内容', 'error');
            return;
        }
        if (CheckUserState()) {
            $.ajax({
                url: "/profile/AJaxCreateReply",
                type: 'post',
                dataType: 'text',
                timeout: 10000,
                data: { Des: Des, ReplyId: ReplyId },
                success: function (resultData) {
                    $("#MaticsoftTopicReply").prepend(resultData);
                    ObjectThis.parents(".answer_a_wn_c").find("input").val("");
                    $('body,html').animate({ scrollTop: 0 }, 1000);

                    //                    var mediaIds = "";
                    //                    if (ObjectThis.parents(".answer_a_wn_d").find(".isSendAll").attr('checked') != undefined) {
                    //                        mediaIds = "-1";
                    //                    } else {
                    //                        var i = 0;
                    //                        ObjectThis.parents(".answer_a_wn_d").find(".bind>span").each(function () {
                    //                            if ($(this).attr("s_type") == "1" && $(this).attr("value") != "") {
                    //                                if (i == 0) {
                    //                                    mediaIds = $(this).attr("value");
                    //                                } else {
                    //                                    mediaIds = mediaIds + "," + $(this).attr("value");
                    //                                }
                    //                                i++;
                    //                            }
                    //                        });
                    //                    }
                    //                    alert(mediaIds);
                    //                    //同步到微博
                    //                    var Option = {
                    //                        ShareDes: Des,
                    //                        TopicID: ReplyId
                    //                    };
                    //                    InfoSync.InfoSending(Option);
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    ShowFailTip("操作失败：" + errorThrown);
                }
            });
        }
    });
    Upload($("#UploadPhoto"));
    $("#addProduct").click(addProduct);
    $("#LoadUrlShow").click(function () { $("#LoadProductWindow").fadeIn(300) });
    $("#LoadUrlClose").click(function () { $("#LoadProductWindow").fadeOut(300) });
    $("#biaoqingclose").click(function () { $("#tbiaoqing").hide(); });
    $(".biaoqingshow").click(function (e) {
        e.preventDefault();
        $("#tbiaoqing").slideToggle(0)
    });
    $("#CancelImage").click(function (e) {
        e.preventDefault();
        $("#yulanImage").fadeOut(300);
    });
    $("#PostReply").click(function () {
        var Des = $("#contentTopic").val();
        var GroupId = $("#GroupId").val();
        var TopicId = $("#TopicId").val();
        var ObjectThis = $(this);
        if (Des == "") {
            $.jBox.tip('请填写内容', 'error');
            return;
        }
        if (CheckUserState()) {
            $.jBox.tip("发布中，请稍后...", 'loading');
            $.ajax({
                url: "/profile/AJaxCreateTopicReply",
                type: 'post',
                dataType: 'text',
                timeout: 10000,
                data: { ImageUrl: ImageUrl, Des: Des, Pid: Pid, GroupId: GroupId, TopicId: TopicId },
                success: function (resultData) {
                    if (resultData == "No") {
                        //                            ShowFailTip("操作失败，请您重试！");
                        $.jBox.tip("出现异常请重试...", 'error');
                    } else {
                        var mediaIds = "";
                        if (ObjectThis.parents(".whole_fom").find(".isSendAll").attr('checked') != undefined) {
                            mediaIds = "-1";
                        } else {
                            var i = 0;
                            ObjectThis.parents("whole_fom").find(".bind>span").each(function () {
                                if ($(this).attr("s_type") == "1" && $(this).attr("value") != "") {
                                    if (i == 0) {
                                        mediaIds = $(this).attr("value");
                                    } else {
                                        mediaIds = mediaIds + "," + $(this).attr("value");
                                    }
                                    i++;
                                }
                            });
                        }
                        var ReplyId = $(resultData).find(".replyTopic").attr("replyid");
          
                        //同步到微博
                        var Option = {
                            ShareDes: Des,
                            ImageUrl: ImageUrl,
                            TopicID: TopicId,
                            ReplyId: ReplyId,
                            mediaIds: mediaIds
                        };
                        InfoSync.InfoSending(Option);
                        $("#yulanImage").fadeOut(300);
                        ImageUrl = "";
                        Pid = "";
                        $("#contentTopic").val("");
                        $("#MaticsoftTopicReply").prepend(resultData);
                        $.jBox.tip("发布成功...", 'success');


                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    ShowFailTip("操作失败：" + errorThrown);
                }
            });
        }
    });
});
function Upload(control) {
    var button = control, interval;
    var fileType = "all", fileNum = "more";
    new AjaxUpload(button, {
        action: '/Ajax_Handle/SNSUploadPhoto.ashx',
        data: {
            'Type': 'Post'
        },
        name: 'myfile',
        onSubmit: function (file, ext) {
            $.jBox.tip("正在上传...", 'loading');
            if (fileType == "pic") {
                if (ext && /^(jpg|png|jpeg|gif)$/.test(ext)) {
                    this.setData({
                        'info': '文件类型为图片'
                    });
                } else {
                    $.jBox.tip('请上传图片类型');
                    return false;
                }
            }
            if (fileNum == 'one')
                this.disable();
        },
        onComplete: function (file, response) {
            if (response == "-1") {
                $.jBox.tip('上传图片不能大于500k');
                return;
            }
            $.jBox.tip('上传成功', 'success');
            ImageUrl = response;
            $("#yulantu").attr("src", ImageUrl.split("|")[2]);
            $("#yulanImage").fadeIn(300);

        }
    });
}
function addProduct() {
    if (CheckUserState()) {
        var LinkUrl = $("#ProductLink").val() + "&";
        ImageUrl = "";
        var urlreg = /http(s)?:\/\/([\w-]+\.)+[\w-]+(\/[\w- .\/?%&=]*)?/;
        if (LinkUrl && LinkUrl.length > 0 &&
                        !urlreg.test(LinkUrl)) {
            $.jBox.tip('请输入正确的链接', 'success');
            return false;
        }
        $.jBox.tip("努力给您获取中...", 'loading');
        $.ajax({
            url: "/profile/AjaxGetProductInfo",
            type: 'post', dataType: 'text', timeout: 10000,
            data: { ProductLink: LinkUrl },
            success: function (resultData) {
                if (resultData == "No") {
                    $.jBox.tip('亲，获取失败，请您换个商品试一下吧', 'error');
                }
                else {
                    var Datas = resultData.split("|");
                    Pid = Datas[0];
                    ImageUrl = Datas[1];
                    $("#yulantu").attr("src", ImageUrl);
                    $("#yulanImage").fadeIn(300);
                    $.jBox.tip('获取成功', 'success');
                    $("#LoadProductWindow").fadeOut(300)
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $.jBox.tip('出现异常', 'error');
            }
        });
    }
}
function insertsmilie(smilieface) {
    $("[id$='contentTopic']").val($("[id$='contentTopic']").val() + smilieface);
    $("#tbiaoqing").hide();
}