﻿
var waterFall = {
    albumId: 0,
    currentAjaxStartIndexHF: null,
    startIndex: 0,
    endIndex: 0,

    container: null,
    columnNumber: 4,
    indexImage: 0,

    scrollTop: document.documentElement.scrollTop || document.body.scrollTop,

    loadFinish: false,

    // 滚动加载
    scroll: function () {
        window.onscroll = function () {
            // 为提高性能，滚动前后距离大于100像素再处理
            var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            if (!waterFall.loadFinish && Math.abs(scrollTop - waterFall.scrollTop) > 100) {
                waterFall.scrollTop = scrollTop;
                waterFall.appendDetect();
               
            }
        };
        return this;
    },

    // 是否滚动载入的检测
    appendDetect: function () {
        var start = 0;
        for (start; start < this.columnNumber; start++) {
            eleColumn = document.getElementById("col_" + start);
            if (eleColumn && !this.loadFinish) {
                if (eleColumn.offsetTop + eleColumn.clientHeight < this.scrollTop + (window.innerHeight || document.documentElement.clientHeight)) {
                    this.append(eleColumn);
                }
            }
        }

        return this;
    },

    // 滚动载入
    append: function (column) {
        if (this.startIndex >= this.endIndex) {
            loadFinish = true;
            return this;
        }
        $.ajax({
            type: "POST",
            url: "WaterfallProductListData",
            async: false,
            dataType: "html",
            data: { AlbumID: this.albumId, startIndex: this.startIndex },
            success: function (data) {
                if (!data) {
                    //减少无效请求, 一次无数据后停止瀑布流
                    loadFinish = true;
                    return;
                }
                waterFall.indexImage += 1;
                waterFall.currentAjaxStartIndexHF.val(++waterFall.startIndex);
                console.debug("Waterfall load data Index:" + waterFall.startIndex);
                $(column).append(data);
            }
        });
        return this;
    },

    refresh: function () {
        // 检测
        this.appendDetect();
        return this;
    },

    // 浏览器窗口大小变换
    resize: function () {
        window.onresize = function () {
            waterFall.refresh();
        };
        return this;
    },

    init: function () {
        if ($('#hfCurrentPageAjaxStartIndex').length == 0) return;
        this.currentAjaxStartIndexHF = $('#hfCurrentPageAjaxStartIndex');
        if ($('#hfCurrentPageAjaxEndIndex').length == 0) return;

        if ($(".imagewalls_id").length == 0) return;
        this.container = $(".imagewalls_id");
        this.startIndex = this.currentAjaxStartIndexHF.val() ? parseInt(this.currentAjaxStartIndexHF.val()) : 0;
        this.endIndex = $('#hfCurrentPageAjaxEndIndex').val() ? parseInt($('#hfCurrentPageAjaxEndIndex').val()) : 0;
//        this.albumId = $.getUrlParam('AlbumID');

//        if (this.albumId && this.startIndex && this.container.length) {
//            $(document).scrollTop(0);
//            this.loadFinish = false;
//            this.scroll().resize();
        //        }

        //        this.albumId = $.getUrlParam('AlbumID');

               if ( this.startIndex && this.container.length) {
                   $(document).scrollTop(0);
                  this.loadFinish = false;
                  this.scroll().resize();
               }
    }
};
